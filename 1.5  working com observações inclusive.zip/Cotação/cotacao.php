<?php
/*
Plugin Name: Cotação
Plugin URI: https://seudominio.com
Description: Permite que o cliente solicite orçamento em vez de finalizar pedido no WooCommerce, incluindo apenas as observações do produto.
Version: 1.5
Author: Seu Nome
Author URI: https://seudominio.com
License: GPL2
*/

// Bloqueia acesso direto
if ( !defined( 'ABSPATH' ) ) exit;

// Adiciona o botão no carrinho
add_action( 'woocommerce_proceed_to_checkout', 'cotacao_add_request_quote_button', 20 );
function cotacao_add_request_quote_button() {
    echo '<a href="' . esc_url( add_query_arg( 'solicitar_orcamento', 'true', wc_get_cart_url() ) ) . '" 
             class="button alt">Solicitar Orçamento</a>';
}

// Intercepta o clique e cria um pedido com status "cotacao"
add_action( 'template_redirect', 'cotacao_process_quote_request' );
function cotacao_process_quote_request() {
    if ( isset($_GET['solicitar_orcamento']) && $_GET['solicitar_orcamento'] === 'true' && !WC()->cart->is_empty() ) {
        
        $current_user = wp_get_current_user();

        // Cria pedido vazio
        $order = wc_create_order();

        // Adiciona produtos do carrinho ao pedido
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            $item_id = $order->add_product(
                $cart_item['data'],
                $cart_item['quantity'],
                array(
                    'variation' => $cart_item['variation'],
                )
            );

            // Captura apenas o campo "Prad selection"
            if ( isset($cart_item['prad_selection']) ) {
                $prad_selection = maybe_unserialize( $cart_item['prad_selection'] );

                if ( isset($prad_selection['extra_data'][0]['name']) 
                    && $prad_selection['extra_data'][0]['name'] === 'Observações sobre o trabalho' 
                    && !empty($prad_selection['extra_data'][0]['value']) ) {

                    wc_add_order_item_meta(
                        $item_id,
                        'Observações',
                        sanitize_textarea_field( $prad_selection['extra_data'][0]['value'] )
                    );
                }
            }
        }

        // Define dados do cliente
        if ( $current_user->ID ) {
            $order->set_customer_id( $current_user->ID );
        }

        // Define status "cotacao"
        $order->update_status( 'cotacao', 'Pedido de orçamento solicitado.' );

        // Esvazia o carrinho
        WC()->cart->empty_cart();

        // Redireciona para página do carrinho com mensagem
        wp_safe_redirect( add_query_arg( 'cotacao_recebida', 'true', wc_get_cart_url() ) );
        exit;
    }
}

// Mensagem de confirmação
add_action( 'woocommerce_before_cart', 'cotacao_thank_you_message' );
function cotacao_thank_you_message() {
    if ( isset($_GET['cotacao_recebida']) && $_GET['cotacao_recebida'] === 'true' ) {
        wc_print_notice( 'Sua solicitação de orçamento foi enviada com sucesso! Em breve entraremos em contato.', 'success' );
    }
}

// Adiciona novo status "cotacao" ao WooCommerce
add_action( 'init', 'cotacao_register_status' );
function cotacao_register_status() {
    register_post_status( 'wc-cotacao', array(
        'label'                     => _x( 'Cotação', 'Order status', 'woocommerce' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Cotação (%s)', 'Cotações (%s)' )
    ) );
}

// Adiciona o status à lista de pedidos do WooCommerce
add_filter( 'wc_order_statuses', 'cotacao_add_to_order_statuses' );
function cotacao_add_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();

    // Coloca "Cotação" depois de "Pagamento pendente"
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-pending' === $key ) {
            $new_order_statuses['wc-cotacao'] = _x( 'Cotação', 'Order status', 'woocommerce' );
        }
    }

    return $new_order_statuses;
}

// Exibir somente Observações no e-mail e na tela do pedido
add_action( 'woocommerce_order_item_meta_end', 'cotacao_exibir_observacoes_emails', 10, 4 );
function cotacao_exibir_observacoes_emails( $item_id, $item, $order, $plain_text ) {
    $observacoes = wc_get_order_item_meta( $item_id, 'Observações', true );

    if ( $observacoes ) {
        echo '<p><strong>Observações:</strong> ' . esc_html( $observacoes ) . '</p>';
    }
}
