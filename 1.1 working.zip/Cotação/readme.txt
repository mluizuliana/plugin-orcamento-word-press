=== Cotação ===
Contributors: seu_nome
Tags: woocommerce, orçamento, cotação
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plugin para WooCommerce que adiciona a funcionalidade de solicitar orçamento no lugar do checkout.
